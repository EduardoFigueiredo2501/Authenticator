# Portal 360 — Authenticator (BFF)

Backend Spring Boot que recebe matrícula/senha da SPA (Vue/Nuxt) e chama o Keycloak (OIDC) usando **password grant**.
O Keycloak valida no LDAP via User Federation (já configurado no Keycloak).

## Endpoints
- POST `/api/auth/login`
- GET  `/api/auth/me`
- POST `/api/auth/refresh`
- POST `/api/auth/logout`
- GET  `/api/auth/session`
- GET  `/healthz`

## Swagger / OpenAPI
- UI: `/swagger-ui.html`
- OpenAPI JSON: `/v3/api-docs`

## Segurança
- Cookie de sessão: HttpOnly + Secure + SameSite (configurável).
- CORS: allowlist em `app.security.allowedOrigins`.
- Mitigação CSRF prática: `OriginCheckFilter` valida Origin/Referer em POST/PUT/DELETE.
- Respostas do filtro são templates JSON em `src/main/resources/errors/`.

## Docker
```bash
docker build -t portal-360-authenticator:0.1.0 .
docker run --rm -p 8080:8080   -e OIDC_ISSUER_BASE_URL="https://sso.pm.ba.gov.br"   -e OIDC_REALM="portal-360"   -e OIDC_CLIENT_ID="portal-360-auth"   -e OIDC_CLIENT_SECRET="***"   -e CORS_ALLOWED_ORIGIN_1="http://localhost:5173"   portal-360-authenticator:0.1.0
```

## Kubernetes
Manifests em `k8s/` (ConfigMap + Secret + Deployment + Service + Ingress).
