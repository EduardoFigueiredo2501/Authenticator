package br.gov.pmba.portal360.authbff;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
public class AuthBffApplication {
    public static void main(String[] args) {
        SpringApplication.run(AuthBffApplication.class, args);
    }
}
