package br.gov.pmba.portal360.authbff.audit.contract;

import br.gov.pmba.portal360.authbff.audit.dto.AuditRequestData;

public interface AuditRecorder {

    void registrarLoginSucesso(AuditRequestData data);

    void registrarLoginFalha(AuditRequestData data);

    void registrarLogout(AuditRequestData data);

}