package br.gov.pmba.portal360.authbff.audit.dto;

import lombok.Builder;

@Builder
public record AuditRequestData(
        String usuarioId,
        String username,
        String ip,
        String userAgent,
        String erro
) {
}