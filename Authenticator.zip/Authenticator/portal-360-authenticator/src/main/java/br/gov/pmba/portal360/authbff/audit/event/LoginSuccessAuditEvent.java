package br.gov.pmba.portal360.authbff.audit.event;

import br.gov.pmba.portal360.authbff.audit.dto.AuditRequestData;

public record LoginSuccessAuditEvent(
        AuditRequestData data
) {
}