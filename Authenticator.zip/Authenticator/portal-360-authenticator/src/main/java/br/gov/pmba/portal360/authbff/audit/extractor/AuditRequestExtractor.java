package br.gov.pmba.portal360.authbff.audit.extractor;

import br.gov.pmba.portal360.authbff.audit.dto.AuditRequestData;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Component;

@Component
public class AuditRequestExtractor {

    public AuditRequestData extract(
            HttpServletRequest request,
            String usuarioId,
            String username,
            String erro
    ) {

        return AuditRequestData.builder()
                .usuarioId(usuarioId)
                .username(username)
                .ip(extractIp(request))
                .userAgent(request.getHeader("User-Agent"))
                .erro(erro)
                .build();
    }

    private String extractIp(HttpServletRequest request) {

        String forwarded =
                request.getHeader("X-Forwarded-For");

        if (forwarded != null && !forwarded.isBlank()) {
            return forwarded.split(",")[0].trim();
        }

        return request.getRemoteAddr();
    }
}