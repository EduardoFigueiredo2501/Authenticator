package br.gov.pmba.portal360.authbff.audit.listener;

import br.gov.pmba.portal360.authbff.audit.contract.AuditRecorder;
import br.gov.pmba.portal360.authbff.audit.event.LoginFailureAuditEvent;
import br.gov.pmba.portal360.authbff.audit.event.LoginSuccessAuditEvent;
import br.gov.pmba.portal360.authbff.audit.event.LogoutAuditEvent;
import lombok.RequiredArgsConstructor;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class AuditEventListener {

    private final AuditRecorder auditRecorder;

    @Async
    @EventListener
    public void handle(LoginSuccessAuditEvent event) {
        auditRecorder.registrarLoginSucesso(event.data());
    }

    @Async
    @EventListener
    public void handle(LoginFailureAuditEvent event) {
        auditRecorder.registrarLoginFalha(event.data());
    }

    @Async
    @EventListener
    public void handle(LogoutAuditEvent event) {
        auditRecorder.registrarLogout(event.data());
    }
}