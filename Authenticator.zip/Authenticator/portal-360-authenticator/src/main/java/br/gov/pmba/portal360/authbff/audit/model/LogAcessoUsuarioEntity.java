package br.gov.pmba.portal360.authbff.audit.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UuidGenerator;

import java.time.LocalDateTime;
import java.util.UUID;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tb_log_acesso_usuario")
public class LogAcessoUsuarioEntity {

    @Id
    @UuidGenerator
    @Column(name = "id", nullable = false)
    private UUID id;

    @Column(name = "data_hora_evento")
    private LocalDateTime dataHoraEvento;

    @Column(name = "identificador_usuario")
    private String identificadorUsuario;

    @Column(name = "usuario_id")
    private String usuarioId;

    @Enumerated(EnumType.STRING)
    @Column(name = "tipo_evento", nullable = false)
    private TipoEventoAcesso tipoEvento;

    @Enumerated(EnumType.STRING)
    @Column(name = "resultado", nullable = false)
    private ResultadoEventoAcesso resultado;

    @Column(name = "ip_origem")
    private String ipOrigem;

    @Column(name = "user_agent")
    private String userAgent;

    @Column(name = "metodo_http")
    private String metodoHttp;

    @Column(name = "uri")
    private String uri;

    @Column(name = "status_http")
    private Integer statusHttp;

    @Column(name = "motivo_erro")
    private String motivoErro;

    @Column(name = "dados", columnDefinition = "jsonb")
    private String dados;

    @Column(name = "criado_em")
    private LocalDateTime criadoEm;

    @PrePersist
    public void prePersist() {
        LocalDateTime now = LocalDateTime.now();

        if (criadoEm == null) {
            criadoEm = now;
        }

        if (dataHoraEvento == null) {
            dataHoraEvento = now;
        }
    }
}