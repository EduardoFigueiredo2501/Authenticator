package br.gov.pmba.portal360.authbff.audit.model;

public enum TipoEventoAcesso {

    LOGIN,
    LOGOUT

}