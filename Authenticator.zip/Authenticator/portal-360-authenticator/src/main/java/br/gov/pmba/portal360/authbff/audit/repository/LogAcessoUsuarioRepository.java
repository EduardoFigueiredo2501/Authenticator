package br.gov.pmba.portal360.authbff.audit.repository;

import br.gov.pmba.portal360.authbff.audit.model.LogAcessoUsuarioEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LogAcessoUsuarioRepository
        extends JpaRepository<LogAcessoUsuarioEntity, Long> {
}