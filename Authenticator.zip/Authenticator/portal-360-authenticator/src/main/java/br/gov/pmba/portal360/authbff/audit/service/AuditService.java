package br.gov.pmba.portal360.authbff.audit.service;

import br.gov.pmba.portal360.authbff.audit.contract.AuditRecorder;
import br.gov.pmba.portal360.authbff.audit.dto.AuditRequestData;
import br.gov.pmba.portal360.authbff.audit.model.LogAcessoUsuarioEntity;
import br.gov.pmba.portal360.authbff.audit.model.ResultadoEventoAcesso;
import br.gov.pmba.portal360.authbff.audit.model.TipoEventoAcesso;
import br.gov.pmba.portal360.authbff.audit.repository.LogAcessoUsuarioRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuditService implements AuditRecorder {

    private final LogAcessoUsuarioRepository repository;

    @Override
    public void registrarLoginSucesso(AuditRequestData data) {
        salvar(data, TipoEventoAcesso.LOGIN, ResultadoEventoAcesso.SUCESSO);
    }

    @Override
    public void registrarLoginFalha(AuditRequestData data) {
        salvar(data, TipoEventoAcesso.LOGIN, ResultadoEventoAcesso.FALHA);
    }

    @Override
    public void registrarLogout(AuditRequestData data) {
        salvar(data, TipoEventoAcesso.LOGOUT, ResultadoEventoAcesso.SUCESSO);
    }

    private void salvar( AuditRequestData data, TipoEventoAcesso tipoEvento, ResultadoEventoAcesso resultado ) {
        try {
            LogAcessoUsuarioEntity entity = LogAcessoUsuarioEntity.builder()
                    .usuarioId(data.usuarioId())
                    .identificadorUsuario(data.username())
                    .tipoEvento(tipoEvento)
                    .resultado(resultado)
                    .ipOrigem(data.ip())
                    .userAgent(data.userAgent())
                    .motivoErro(data.erro())
                    .build();
            repository.save(entity);
        }
        catch (Exception ex) {
            log.error( "Erro ao registrar auditoria de acesso", ex );
        }
    }
}