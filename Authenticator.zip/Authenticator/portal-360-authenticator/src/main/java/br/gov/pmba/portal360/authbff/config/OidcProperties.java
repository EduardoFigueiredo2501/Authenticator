package br.gov.pmba.portal360.authbff.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "app.oidc")
public record OidcProperties(
        String issuerBaseUrl,
        String realm,
        String clientId,
        String clientSecret,
        String scopes,
        String logoutEndpoint,
        String portalBaseUrl,
        String redirectUri
) {
    public String tokenEndpoint() {
        return issuerBaseUrl + "/realms/" + realm + "/protocol/openid-connect/token";
    }

    public String userInfoEndpoint() {
        return issuerBaseUrl + "/realms/" + realm + "/protocol/openid-connect/userinfo";
    }
}
