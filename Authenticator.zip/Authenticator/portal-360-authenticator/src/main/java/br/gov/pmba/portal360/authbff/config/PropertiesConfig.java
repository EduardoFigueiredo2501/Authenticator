package br.gov.pmba.portal360.authbff.config;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties({OidcProperties.class, SecurityProps.class})
public class PropertiesConfig { }
