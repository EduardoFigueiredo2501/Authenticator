package br.gov.pmba.portal360.authbff.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.List;

@ConfigurationProperties(prefix = "app.security")
public record SecurityProps(List<String> allowedOrigins) { }
