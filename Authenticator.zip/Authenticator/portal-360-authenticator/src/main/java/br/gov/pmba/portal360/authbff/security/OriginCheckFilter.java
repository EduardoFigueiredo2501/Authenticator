package br.gov.pmba.portal360.authbff.security;

import br.gov.pmba.portal360.authbff.config.SecurityProps;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.net.URI;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

@Component
public class OriginCheckFilter extends OncePerRequestFilter {

    private final Set<String> allowed;
    private final ObjectMapper objectMapper;

    public OriginCheckFilter(SecurityProps props, ObjectMapper objectMapper) {
        this.allowed = new HashSet<>(props.allowedOrigins());
        this.objectMapper = objectMapper;
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String method = request.getMethod();
        return HttpMethod.GET.matches(method)
                || HttpMethod.HEAD.matches(method)
                || HttpMethod.OPTIONS.matches(method);
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {

        String origin = request.getHeader("Origin");
        String referer = request.getHeader("Referer");
        String source = (origin != null) ? origin : referer;

        if (source == null || source.isBlank()) {
            writeJson(response, HttpServletResponse.SC_FORBIDDEN, Map.of("error", "origin_required"));
            return;
        }

        String normalized = normalizeOrigin(source);
        if (!allowed.contains(normalized)) {
            writeJson(response, HttpServletResponse.SC_FORBIDDEN,
                    Map.of("error", "origin_not_allowed", "origin", normalized));
            return;
        }

        filterChain.doFilter(request, response);
    }

    private void writeJson(HttpServletResponse response, int status, Map<String, Object> body) throws IOException {
        response.setStatus(status);
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        objectMapper.writeValue(response.getWriter(), body);
    }

    private static String normalizeOrigin(String value) {
        try {
            URI uri = URI.create(value);
            String scheme = uri.getScheme();
            String host = uri.getHost();
            int port = uri.getPort();
            if (scheme == null || host == null) return value;
            return (port > 0) ? scheme + "://" + host + ":" + port : scheme + "://" + host;
        } catch (Exception e) {
            return value;
        }
    }
}
