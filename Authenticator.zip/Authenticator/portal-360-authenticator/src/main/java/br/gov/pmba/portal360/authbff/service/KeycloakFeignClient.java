package br.gov.pmba.portal360.authbff.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;

@FeignClient(
        name = "keycloak",
        url = "${app.oidc.issuerBaseUrl}"
)
public interface KeycloakFeignClient {

    @PostMapping(
            value = "/realms/{realm}/protocol/openid-connect/token",
            consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE
    )
    Map<String, Object> token(@RequestParam("realm") String realm, MultiValueMap<String, String> form);

    @GetMapping(value = "/realms/{realm}/protocol/openid-connect/userinfo")
    Map<String, Object> userInfo(@RequestParam("realm") String realm,
                                 @RequestHeader("Authorization") String authorization);
}
