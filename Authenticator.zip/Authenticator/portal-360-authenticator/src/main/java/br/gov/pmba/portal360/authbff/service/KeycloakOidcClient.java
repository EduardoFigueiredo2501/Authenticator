package br.gov.pmba.portal360.authbff.service;

import br.gov.pmba.portal360.authbff.config.OidcProperties;
import br.gov.pmba.portal360.authbff.web.dto.OidcTokenResponse;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.util.Map;

@Service
public class KeycloakOidcClient {

    private final OidcProperties props;
    private final KeycloakFeignClient feign;

    public KeycloakOidcClient(OidcProperties props, KeycloakFeignClient feign) {
        this.props = props;
        this.feign = feign;
    }

    public OidcTokenResponse passwordGrant(String username, String password) {
        MultiValueMap<String, String> form = new LinkedMultiValueMap<>();
        form.add("grant_type", "password");
        form.add("client_id", props.clientId());
        form.add("client_secret", props.clientSecret());
        form.add("username", username);
        form.add("password", password);
        form.add("scope", props.scopes());

        Map<String, Object> m = feign.token(props.realm(), form);
        return OidcTokenResponse.from(m);
    }

    public OidcTokenResponse refresh(String refreshToken) {
        MultiValueMap<String, String> form = new LinkedMultiValueMap<>();
        form.add("grant_type", "refresh_token");
        form.add("client_id", props.clientId());
        form.add("client_secret", props.clientSecret());
        form.add("refresh_token", refreshToken);

        Map<String, Object> m = feign.token(props.realm(), form);
        return OidcTokenResponse.from(m);
    }

    public Map<String, Object> userInfo(String accessToken) {
        return feign.userInfo(props.realm(), "Bearer " + accessToken);
    }

    public String buildLogoutUrl(String idTokenHint, String postLogoutRedirectUri) {
        // Keycloak: /protocol/openid-connect/logout?id_token_hint=...&post_logout_redirect_uri=...
        String base = props.logoutEndpoint();
        if (idTokenHint == null || idTokenHint.isBlank()) {
            return base + "?post_logout_redirect_uri=" + enc(postLogoutRedirectUri);
        }
        return base + "?id_token_hint=" + enc(idTokenHint) + "&post_logout_redirect_uri=" + enc(postLogoutRedirectUri);
    }

    private static String enc(String v) {
        return java.net.URLEncoder.encode(v, java.nio.charset.StandardCharsets.UTF_8);
    }
}
