package br.gov.pmba.portal360.authbff.web;

import br.gov.pmba.portal360.authbff.config.OidcProperties;
import br.gov.pmba.portal360.authbff.service.KeycloakOidcClient;
import br.gov.pmba.portal360.authbff.web.dto.OidcTokenResponse;
import br.gov.pmba.portal360.authbff.web.dto.SessionInfoResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import br.gov.pmba.portal360.authbff.audit.event.LoginFailureAuditEvent;
import br.gov.pmba.portal360.authbff.audit.event.LoginSuccessAuditEvent;
import br.gov.pmba.portal360.authbff.audit.event.LogoutAuditEvent;
import br.gov.pmba.portal360.authbff.audit.extractor.AuditRequestExtractor;
import org.springframework.context.ApplicationEventPublisher;

import java.time.Instant;
import java.util.Map;

@RestController
@Validated
public class AuthController {

    private static final String SESSION_TOKENS = "OIDC_TOKENS";
    private static final String SESSION_CREATED_AT = "SESSION_CREATED_AT";

    private final OidcProperties props;
    private final KeycloakOidcClient oidc;

    private final ApplicationEventPublisher publisher;
    private final AuditRequestExtractor auditRequestExtractor;

    public AuthController(OidcProperties props, KeycloakOidcClient oidc, ApplicationEventPublisher publisher, AuditRequestExtractor auditRequestExtractor) {
        this.props = props;
        this.oidc = oidc;
        this.publisher = publisher;
        this.auditRequestExtractor = auditRequestExtractor;
    }

    @GetMapping("/healthz")
    public Map<String, Object> healthz() {
        return Map.of("status", "ok", "ts", Instant.now().toString());
    }

    public record LoginRequest(@NotBlank String username, @NotBlank String password) {}

    @PostMapping("/api/auth/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest body, HttpServletRequest request) {

        try {

            HttpSession session = request.getSession(true);

            OidcTokenResponse tokens = oidc.passwordGrant(
                    body.username(),
                    body.password()
            );

            if (tokens == null || tokens.accessToken() == null || tokens.accessToken().isBlank()) {

                publisher.publishEvent(
                        new LoginFailureAuditEvent(
                                auditRequestExtractor.extract(
                                        request,
                                        null,
                                        body.username(),
                                        "token_exchange_failed"
                                )
                        )
                );

                return ResponseEntity.status(502)
                        .body(Map.of("error", "token_exchange_failed"));
            }

            session.setAttribute(SESSION_TOKENS, tokens);
            session.setAttribute(SESSION_CREATED_AT, Instant.now().toString());
            session.setAttribute("username", body.username());

            publisher.publishEvent(
                    new LoginSuccessAuditEvent(
                            auditRequestExtractor.extract(
                                    request,
                                    null,
                                    body.username(),
                                    null
                            )
                    )
            );

            return ResponseEntity.ok(Map.of(
                    "status", "authenticated",
                    "sessionId", session.getId(),
                    "expiresIn", tokens.expiresIn(),
                    "tokenType", tokens.tokenType()
            ));

        } catch (Exception ex) {

            publisher.publishEvent(
                    new LoginFailureAuditEvent(
                            auditRequestExtractor.extract(
                                    request,
                                    null,
                                    body.username(),
                                    ex.getMessage()
                            )
                    )
            );

            throw ex;
        }
    }

    @GetMapping("/api/auth/me")
    public ResponseEntity<?> me(HttpServletRequest request) {
        OidcTokenResponse tokens = getTokens(request.getSession(false));
        if (tokens == null) {
            return ResponseEntity.status(401).body(Map.of("error", "not_authenticated"));
        }
        Map<String, Object> userInfo = oidc.userInfo(tokens.accessToken());
        return ResponseEntity.ok(userInfo);
    }

    @PostMapping("/api/auth/refresh")
    public ResponseEntity<?> refresh(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        OidcTokenResponse tokens = getTokens(session);
        if (tokens == null || tokens.refreshToken() == null || tokens.refreshToken().isBlank()) {
            return ResponseEntity.status(401).body(Map.of("error", "no_refresh_token"));
        }

        OidcTokenResponse refreshed = oidc.refresh(tokens.refreshToken());
        if (refreshed == null || refreshed.accessToken() == null) {
            return ResponseEntity.status(502).body(Map.of("error", "refresh_failed"));
        }

        session.setAttribute(SESSION_TOKENS, refreshed);

        return ResponseEntity.ok(Map.of(
                "status", "refreshed",
                "expiresIn", refreshed.expiresIn(),
                "tokenType", refreshed.tokenType()
        ));
    }

    @PostMapping("/api/auth/logout")
    public ResponseEntity<?> logout(@RequestParam(value = "postLogoutRedirectUri", required = false) String postLogoutRedirectUri,
                                    HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        String idToken = null;

        if (session != null) {
            OidcTokenResponse tokens = getTokens(session);
            if (tokens != null) idToken = tokens.idToken();

            String username =
                    (String) session.getAttribute("username");

            publisher.publishEvent(
                    new LogoutAuditEvent(
                            auditRequestExtractor.extract(
                                    request,
                                    null,
                                    username,
                                    null
                            )
                    )
            );
            session.invalidate();
        }

        String redirect = (postLogoutRedirectUri == null || postLogoutRedirectUri.isBlank())
                ? props.portalBaseUrl()
                : postLogoutRedirectUri;

        String logoutUrl = oidc.buildLogoutUrl(idToken, redirect);

        return ResponseEntity.ok(Map.of(
                "status", "logged_out_local",
                "logoutUrl", logoutUrl
        ));
    }

    @GetMapping("/api/auth/session")
    public ResponseEntity<?> sessionInfo(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null) return ResponseEntity.status(401).body(Map.of("error", "no_session"));

        OidcTokenResponse tokens = getTokens(session);
        if (tokens == null) return ResponseEntity.status(401).body(Map.of("error", "not_authenticated"));

        return ResponseEntity.ok(new SessionInfoResponse(
                session.getId(),
                (String) session.getAttribute(SESSION_CREATED_AT),
                tokens.expiresIn(),
                tokens.refreshExpiresIn()
        ));
    }

    private static OidcTokenResponse getTokens(HttpSession session) {
        if (session == null) return null;
        Object v = session.getAttribute(SESSION_TOKENS);
        if (v instanceof OidcTokenResponse t) return t;
        return null;
    }
}
