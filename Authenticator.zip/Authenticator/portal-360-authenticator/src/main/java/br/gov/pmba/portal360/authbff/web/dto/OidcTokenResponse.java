package br.gov.pmba.portal360.authbff.web.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Map;

public record OidcTokenResponse(
        @JsonProperty("access_token") String accessToken,
        @JsonProperty("refresh_token") String refreshToken,
        @JsonProperty("expires_in") long expiresIn,
        @JsonProperty("refresh_expires_in") long refreshExpiresIn,
        @JsonProperty("token_type") String tokenType,
        @JsonProperty("id_token") String idToken,
        String scope
) {
    public static OidcTokenResponse from(Map<String, Object> m) {
        if (m == null) return null;
        return new OidcTokenResponse(
                (String) m.get("access_token"),
                (String) m.get("refresh_token"),
                asLong(m.get("expires_in")),
                asLong(m.get("refresh_expires_in")),
                (String) m.get("token_type"),
                (String) m.get("id_token"),
                (String) m.get("scope")
        );
    }

    private static long asLong(Object v) {
        if (v == null) return 0;
        if (v instanceof Number n) return n.longValue();
        try { return Long.parseLong(String.valueOf(v)); } catch (Exception e) { return 0; }
    }
}
