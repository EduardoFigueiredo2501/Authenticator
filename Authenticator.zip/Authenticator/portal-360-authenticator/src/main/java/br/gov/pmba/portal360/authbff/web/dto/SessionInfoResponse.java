package br.gov.pmba.portal360.authbff.web.dto;

public record SessionInfoResponse(
        String sessionId,
        String createdAt,
        long expiresIn,
        long refreshExpiresIn
) {}
