package br.gov.pmba.portal360.authbff.bdd;

import io.cucumber.junit.platform.engine.Cucumber;

@Cucumber
public class CucumberTest {}
