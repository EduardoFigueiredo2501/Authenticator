package br.gov.pmba.portal360.authbff.bdd.steps;

import com.github.tomakehurst.wiremock.WireMockServer;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class AuthSteps {

    static WireMockServer wireMock;

    @LocalServerPort
    int port;

    int lastStatus;
    String sessionCookie;

    @DynamicPropertySource
    static void props(DynamicPropertyRegistry r) {
        if (wireMock == null) {
            wireMock = new WireMockServer(0);
            wireMock.start();
        }
        String issuerBaseUrl = "http://localhost:" + wireMock.port();
        r.add("app.oidc.issuerBaseUrl", () -> issuerBaseUrl);
        r.add("app.oidc.realm", () -> "portal-360");
        r.add("app.oidc.clientId", () -> "portal-360-auth");
        r.add("app.oidc.clientSecret", () -> "secret");
        r.add("app.oidc.scopes", () -> "openid profile email");
        r.add("app.oidc.logoutEndpoint", () -> issuerBaseUrl + "/realms/portal-360/protocol/openid-connect/logout");

        r.add("app.security.allowedOrigins[0]", () -> "http://localhost:5173");
        r.add("server.servlet.session.cookie.secure", () -> "false"); // teste local
    }

    @Before
    public void before() {
        wireMock.resetAll();
        lastStatus = 0;
        sessionCookie = null;
    }

    @Given("o Keycloak está stubado e respondendo token e userinfo")
    public void stubKeycloak() {
        wireMock.stubFor(post(urlEqualTo("/realms/portal-360/protocol/openid-connect/token"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody("{\"access_token\":\"acc\",\"refresh_token\":\"ref\",\"expires_in\":300,\"refresh_expires_in\":3600,\"token_type\":\"Bearer\",\"id_token\":\"id\",\"scope\":\"openid\"}")));

        wireMock.stubFor(get(urlEqualTo("/realms/portal-360/protocol/openid-connect/userinfo"))
                .withHeader("Authorization", equalTo("Bearer acc"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody("{\"sub\":\"30340324\",\"preferred_username\":\"30340324\",\"email\":\"teste@pm.ba.gov.br\"}")));
    }

    @When("a SPA faz login com usuario {string} e senha {string}")
    public void spaLogin(String user, String pass) throws IOException {
        URL url = URI.create("http://localhost:" + port + "/api/auth/login").toURL();
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Origin", "http://localhost:5173");
        conn.setDoOutput(true);

        String body = "{\"username\":\""+user+"\",\"password\":\""+pass+"\"}";
        conn.getOutputStream().write(body.getBytes(StandardCharsets.UTF_8));

        lastStatus = conn.getResponseCode();

        String setCookie = conn.getHeaderField("Set-Cookie");
        if (setCookie != null) {
            sessionCookie = setCookie.split(";", 2)[0];
        }
        conn.disconnect();
    }

    @Then("a resposta deve ser {int}")
    public void assertStatus(int code) {
        assertThat(lastStatus).isEqualTo(code);
        assertThat(sessionCookie).isNotBlank();
    }

    @Then("a chamada /api/auth/me deve retornar {int} e conter {string}")
    public void callMe(int code, String contains) throws IOException {
        URL url = URI.create("http://localhost:" + port + "/api/auth/me").toURL();
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Origin", "http://localhost:5173");
        conn.setRequestProperty("Cookie", sessionCookie);

        int status = conn.getResponseCode();
        assertThat(status).isEqualTo(code);

        String resp = new String(conn.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
        assertThat(resp).contains(contains);

        conn.disconnect();
    }
}
