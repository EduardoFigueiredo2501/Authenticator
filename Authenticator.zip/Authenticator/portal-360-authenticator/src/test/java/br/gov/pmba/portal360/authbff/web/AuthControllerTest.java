package br.gov.pmba.portal360.authbff.web;

import br.gov.pmba.portal360.authbff.audit.extractor.AuditRequestExtractor;
import br.gov.pmba.portal360.authbff.config.OidcProperties;
import br.gov.pmba.portal360.authbff.service.KeycloakOidcClient;
import br.gov.pmba.portal360.authbff.web.dto.OidcTokenResponse;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

class AuthControllerTest {

    @Test
    void login_shouldStoreTokensInSession() {

        KeycloakOidcClient oidc = Mockito.mock(KeycloakOidcClient.class);

        when(oidc.passwordGrant(anyString(), anyString()))
                .thenReturn(
                        new OidcTokenResponse(
                                "acc",
                                "ref",
                                300,
                                3600,
                                "Bearer",
                                "id",
                                "openid"
                        )
                );

        ApplicationEventPublisher publisher =
                Mockito.mock(ApplicationEventPublisher.class);

        AuditRequestExtractor extractor =
                new AuditRequestExtractor();

        OidcProperties props =
                new OidcProperties(
                        "http://kc",
                        "realm",
                        "cid",
                        "sec",
                        "openid",
                        "http://kc/logout",
                        "http://portal",
                        "http://redir"
                );

        AuthController controller =
                new AuthController(
                        props,
                        oidc,
                        publisher,
                        extractor
                );

        MockHttpServletRequest req = new MockHttpServletRequest();
        MockHttpSession session = new MockHttpSession();

        req.setSession(session);

        var resp =
                controller.login(
                        new AuthController.LoginRequest(
                                "30340324",
                                "pwd"
                        ),
                        req
                );

        assertThat(resp.getStatusCode().value()).isEqualTo(200);
        assertThat(session.getAttribute("OIDC_TOKENS")).isNotNull();
    }

    @Test
    void me_shouldReturn401_whenNoSession() {

        KeycloakOidcClient oidc =
                Mockito.mock(KeycloakOidcClient.class);

        ApplicationEventPublisher publisher =
                Mockito.mock(ApplicationEventPublisher.class);

        AuditRequestExtractor extractor =
                new AuditRequestExtractor();

        OidcProperties props =
                new OidcProperties(
                        "http://kc",
                        "realm",
                        "cid",
                        "sec",
                        "openid",
                        "http://kc/logout",
                        "http://portal",
                        "http://redir"
                );

        AuthController controller =
                new AuthController(
                        props,
                        oidc,
                        publisher,
                        extractor
                );

        MockHttpServletRequest req =
                new MockHttpServletRequest();

        var resp = controller.me(req);

        assertThat(resp.getStatusCode().value()).isEqualTo(401);
    }
}