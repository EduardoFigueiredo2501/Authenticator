Feature: Autenticação via SPA -> Authenticator -> Keycloak

  Scenario: Login e consulta de userinfo
    Given o Keycloak está stubado e respondendo token e userinfo
    When a SPA faz login com usuario "30340324" e senha "senha"
    Then a resposta deve ser 200
    And a chamada /api/auth/me deve retornar 200 e conter "sub"
